<script setup>
import '../components/AboutUs/aboutus.scss';
import Search from '../components/Search/Search.vue';
import AboutUs from '../components/AboutUs/AboutUs.vue';
</script>

<template>
  <div class="page-wrapper">
    <Search />
    <AboutUs />
  </div>
</template>