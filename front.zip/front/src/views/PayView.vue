<script setup>
import Pay from '../components/Pay/Pay.vue';
import Search from '../components/Search/Search.vue';

</script>

<template>
    <div class="page-wrapper">
        <Search />
        <Pay />
    </div>
</template>