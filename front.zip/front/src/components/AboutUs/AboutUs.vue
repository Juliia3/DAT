<script setup>
import './aboutus.scss'
import Title from '../Title/Title.vue';

</script>

<template>
    <section class="about-us">
        <div class="about-us__container container">
            <div class="about-us__title">
                <Title title="Про нас" />
            </div>
            <div class="about-us__article">
                <div class="about-us__text-block">
                    <p class="about-us__text text play-right play">
                        <span class="text-green">«Компанія ТОВ “ДАМАР АГРОТРЕЙД”</span>— молода команда, яка з’явилась
                        на аграрному ринку у 2020 році. Ми не боїмось труднощів і викликів. Тому навіть складний
                        ковідний період, світова пандемія не стали на заваді успішному старту.
                    </p>
                    <p class="about-us__text text play-right play">
                        Отже, <span class="text-green">ми — сміливі, ми — драйвові</span>, ми — ті, що розвивають
                        рослинництво та допомагають ставати успішними тисячам вітчизняних аграріїв.
                    </p>
                    <p class="about-us__text text play-right play">
                        <span class="text-green">Бачення:</span> компанія ТОВ “ДАМАР АГРОТРЕЙД” тримає курс на
                        підвищення престижності, довіри до засобів захисту рослин made in UA. Прагнемо, аби в кожному
                        регіоні України наш споживач мав доступ до якісної продукції та консалтингу від фахівців
                        команди.
                    </p>
                    <p class="about-us__text text play-right play">
                        <span class="text-green">Місія:</span> усе продуктове портфоліо, консультативні послуги ТОВ
                        “ДАМАР АГРОТРЕЙД” направлені на підвищення рентабельності рослинництва в мінливих кліматичних
                        умовах України. Також ставимо собі завдання підвищувати обізнаність клієнтів щодо сучасних
                        методів ведення рослинництва...
                    </p>

                </div>
                <p class="about-us__list text play-right play">
                    <span class="text-green">Цінності:</span>
                <p class="about-us__item">-прозорість ділових стосунків з колегами, контрагентами, клієнтами;</p>
                <p class="about-us__item">-однаково висококласний сервіс для невеликого фермера та потужного холдингу;
                </p>
                <p class="about-us__item">-покращення якості товарів та послуг;</p>
                <p class="about-us__item">-постійна підтримка партнера на усіх етапах виробництва продукції
                    рослинництва;</p>
                <p class="about-us__item">-екологічність у роботі, думках та цілях;</p>
                <p class="about-us__item">-підтримка вітчизняного продукту та вітчизняного виробника;</p>
                <p class="about-us__item">-постійний саморозвиток.…»</p>
                </p>
            </div>
        </div>
    </section>
</template> 